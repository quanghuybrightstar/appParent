import React, {PureComponent} from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  Keyboard,
  Dimensions,
  FlatList,
  ImageBackground,
  Image,
} from 'react-native';
import Header from '../../../../Header/Header';
import SmartScreenBase from '../../../../base/SmartScreenBase';
const {width, height} = Dimensions.get('window');
import styles from './Catagory.Style';
import Carousel from 'react-native-snap-carousel';
import HeaderOnlyBack from '../../../../Header/HeaderOnlyBack';
const Diary = [
  {
    title: 'Vũ Thị Ngọc Ánh',
    mes: 2,
    exam: 1,
    pannan: 4,
    gioitinh: 'nu',
    image: require('../../../../assets/image/gv_liststudent_09.png'),
    email: 'anhcute@gmail.com',
    sdt: '0392334999',
  },
  {
    title: 'Võ Nhị Lang',
    mes: 2,
    exam: 1,
    pannan: 4,
    gioitinh: 'nam',
    image: require('../../../../assets/image/gv_liststudent_11.png'),
    email: 'VoTong@gmail.com',
    sdt: '03923342121',
  },
];
class Catagory extends PureComponent {
  state = {};
  renderItem = ({item, index}) => {
    return (
      <View
        style={{
          width: '76%',
          height: '95%',
          backgroundColor: '#00000030',
          borderRadius: 10,
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <View
          style={{
            width: '45%',
            height: '90%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: width / 3,
              height: width / 3,
              borderRadius: width / 6,
            }}>
            <Image
              style={{
                width: width / 3,
                height: width / 3,
                resizeMode: 'contain',
              }}
              source={item.image}
            />
          </View>
        </View>
        <View
          style={{
            width: '55%',
            height: '90%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View style={{width: '100%', height: width / 3}}>
            <View
              style={{
                width: '100%',
                height: '50%',
                justifyContent: 'center',
                paddingLeft: '10%',
              }}>
              <Text style={{fontSize: 23, color: '#FFF', fontWeight: 'bold'}}>
                {item.title}
              </Text>
            </View>
            <View
              style={{
                width: '100%',
                height: '50%',
                justifyContent: 'center',
                paddingLeft: '10%',
              }}>
              <Text style={{fontSize: 15, color: '#FFF', fontWeight: 'bold'}}>
                {item.email}
              </Text>
              <Text style={{fontSize: 15, color: '#FFF', marginTop: 5}}>
                {item.sdt}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  render() {
    return (
      <ImageBackground
        source={require('../../../../assets/image/imagebackground.png')}
        style={styles.container}>
        <Header title={'Xem thông tin học viên'} />

        <View style={styles.wrapCart}>
          <View style={styles.wrapIdCart}>
            <View style={styles.wrapTextCart} />
          </View>
          <Carousel
            ref={c => {
              this._carousel = c;
            }}
            data={Diary}
            renderItem={this.renderItem}
            sliderWidth={width}
            sliderHeight={height}
            itemWidth={width}
            itemHeight={height}
          />
          <View style={styles.wrapText}>
            <View style={styles.wrapTextCart} />
          </View>
        </View>
        <View style={styles.wrapText1}>
          <ScrollView style={styles.wrapAccountNumber}>
            <TouchableOpacity style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-50.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>
                  Thư viện của tôi
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-51.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>
                  Xem thành tích học viên
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-52.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>License</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('SettingParent');
              }}
              style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-53.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>Cài đặt</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-54.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>Đổi mật khẩu</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('StartScreen');
              }}
              style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-55.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>
                  Liên kết tài khoản
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.text1}>
              <View style={styles.wrapCopy}>
                <Image
                  style={styles.wrapCopy2}
                  source={require('../../../../assets/image/phu-huynh-56.png')}
                />
              </View>
              <View style={styles.wrapView}>
                <Text style={{fontSize: 20, color: '#000'}}>
                  Thoát tài khoản
                </Text>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </ImageBackground>
    );
  }
}

export default Catagory;
